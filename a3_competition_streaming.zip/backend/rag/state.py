rag_engine = None
